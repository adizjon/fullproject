// import apiCall from "../../apiCall";
// import {createSlice} from "@reduxjs/toolkit";
//
// const slice = createSlice({
//     name: "setting",
//     initialState: {
//         settings:[]
//     },
//    reducers:{
//         getSetting:(state, action)=>{
//
//         },
//         setSettingSuccess:(state, action)=>{
//             state.settings=action.payload
//         }
//    }
//
// })
// export default slice.reducer
// export const settingModel=slice.actions
// // function getSettings(){
//     //     apiCall({url:"/api/setting",method:"GET"}).then(({data})=>{
//     //         setSettings(data)
//     //     })
//     // }